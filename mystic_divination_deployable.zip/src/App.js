import React from 'react';
import TarotCard from './components/TarotCard';
import ZodiacCard from './components/ZodiacCard';
import IChingCard from './components/IChingCard';

export default function App() {
  return (
    <div className="app-container">
      <TarotCard />
      <ZodiacCard />
      <IChingCard />
    </div>
  );
}