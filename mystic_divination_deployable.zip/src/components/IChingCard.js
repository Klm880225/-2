import React, { useState } from 'react';
import { motion } from 'framer-motion';

const hexagrams = ['乾卦', '坤卦', '屯卦', '蒙卦', '需卦', '讼卦'];
const randomItem = arr => arr[Math.floor(Math.random() * arr.length)];

export default function IChingCard() {
  const [hexagram, setHexagram] = useState(null);
  return (
    <motion.div
      whileHover={{ y: -5 }}
      onClick={() => setHexagram(randomItem(hexagrams))}
      className="iching-card"
    >
      {Array.from({ length: 6 }).map((_, i) => (
        <motion.div
          key={i}
          animate={{ backgroundColor: ['#fff', '#ffb74d', '#fff'] }}
          transition={{ repeat: Infinity, duration: 2, delay: i * 0.2 }}
          className="iching-line"
        ></motion.div>
      ))}
      <div className="hexagram-name">{hexagram || '卦象'}</div>
    </motion.div>
  );
}