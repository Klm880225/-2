import React, { useState } from 'react';
import { motion } from 'framer-motion';

const tarotCards = ['愚者', '魔术师', '女祭司', '皇后', '皇帝', '恋人', '战车', '力量'];
const randomItem = arr => arr[Math.floor(Math.random() * arr.length)];

export default function TarotCard() {
  const [card, setCard] = useState(null);
  return (
    <motion.div
      whileHover={{ scale: 1.1, rotate: 5 }}
      whileTap={{ rotate: 20, y: -100 }}
      onClick={() => setCard(randomItem(tarotCards))}
      className="tarot-card"
    >
      {card || '抽牌'}
    </motion.div>
  );
}