import React, { useState } from 'react';
import { motion } from 'framer-motion';

const zodiacSigns = ['白羊座', '金牛座', '双子座', '巨蟹座', '狮子座', '处女座'];
const randomItem = arr => arr[Math.floor(Math.random() * arr.length)];

export default function ZodiacCard() {
  const [sign, setSign] = useState(null);
  return (
    <motion.div
      whileHover={{ scale: 1.1, rotate: 10, boxShadow: '0 0 20px #ffeb3b' }}
      onClick={() => setSign(randomItem(zodiacSigns))}
      className="zodiac-card"
    >
      {sign || '星座'}
    </motion.div>
  );
}